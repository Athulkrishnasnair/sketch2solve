import { test, expect } from '@playwright/test'
import path from 'node:path'

test.describe('Sketch2Solve UX Enhancements & Branding Suite', () => {
  test('1. First-time onboarding, name persistence, and profile renaming', async ({ page }) => {
    // 1. Visit with fresh storage
    await page.goto('/')
    await page.evaluate(() => {
      localStorage.clear()
    })
    await page.reload()

    // 2. Verify onboarding modal appears with question & official logo
    const onboardingOverlay = page.locator('.onboarding-overlay')
    await expect(onboardingOverlay).toBeVisible({ timeout: 8_000 })
    await expect(page.locator('.onboarding-title')).toContainText('Welcome to Sketch2Solve')
    await expect(page.locator('.input-label')).toContainText('What should we call you?')

    const logoImg = page.locator('.onboarding-logo')
    await expect(logoImg).toBeVisible()
    expect(await logoImg.getAttribute('src')).toBe('/logo.png')

    // Capture screenshot: Onboarding Modal
    await page.screenshot({ path: path.resolve('qa-output/screenshots/01-onboarding-modal.png') })

    // 3. Fill in name and submit
    const nameInput = page.locator('#name-input')
    await nameInput.fill('Dr. Evelyn Reed')
    await page.locator('.btn-continue').click()

    // 4. Modal should close and header should display name
    await expect(onboardingOverlay).not.toBeVisible()
    const userNameText = page.locator('.user-name-text')
    await expect(userNameText).toHaveText('Dr. Evelyn Reed')

    // 5. Reload: name persists and onboarding does NOT re-appear
    await page.reload()
    await expect(page.locator('.onboarding-overlay')).not.toBeVisible()
    await expect(page.locator('.user-name-text')).toHaveText('Dr. Evelyn Reed')

    // Capture screenshot: Dashboard Returning User
    await page.screenshot({ path: path.resolve('qa-output/screenshots/02-dashboard-returning-user.png') })

    // 6. Test Profile Menu & Rename
    await page.locator('.user-profile-btn').click()
    const userMenu = page.locator('.user-dropdown-menu')
    await expect(userMenu).toBeVisible()
    await expect(page.locator('.menu-username')).toHaveText('Dr. Evelyn Reed')

    // Click "Change name"
    await page.locator('.menu-item', { hasText: 'Change name' }).click()
    await expect(page.locator('.onboarding-overlay')).toBeVisible()
    await expect(page.locator('.onboarding-title')).toContainText('Update Your Profile')

    await page.locator('#name-input').fill('Evelyn R.')
    await page.locator('.btn-continue').click()

    await expect(page.locator('.onboarding-overlay')).not.toBeVisible()
    await expect(page.locator('.user-name-text')).toHaveText('Evelyn R.')
  })

  test('2. Interactive Getting Started Guide walkthrough across 9 steps', async ({ page }) => {
    await page.goto('/')

    // Launch guide from sidebar
    const guideNavBtn = page.locator('.nav-guide-btn')
    await expect(guideNavBtn).toBeVisible()
    await guideNavBtn.click()

    const guideContainer = page.locator('.guide-container')
    await expect(guideContainer).toBeVisible()

    // Step 1: Workspace & Dashboard
    await expect(page.locator('.step-title')).toContainText('1. Workspace & Dashboard')
    await expect(page.locator('.step-indicator')).toContainText('Step 1 of 9')

    // Capture screenshot: Guide Step 1
    await page.screenshot({ path: path.resolve('qa-output/screenshots/03-getting-started-step1.png') })

    // Click Next -> Step 2
    await page.locator('.btn-next').click()
    await expect(page.locator('.step-title')).toContainText('2. Uploading a Sketch')
    await expect(page.locator('.step-indicator')).toContainText('Step 2 of 9')

    // Click step dot 4 directly
    const stepDots = page.locator('.step-dot')
    await stepDots.nth(3).click()
    await expect(page.locator('.step-title')).toContainText('4. Correcting Joints & Members')

    // Capture screenshot: Guide Step 4
    await page.screenshot({ path: path.resolve('qa-output/screenshots/04-getting-started-step4.png') })

    // Click step dot 9 directly (final step)
    await stepDots.nth(8).click()
    await expect(page.locator('.step-title')).toContainText('9. Saving & Multi-Format Export')
    const finishBtn = page.locator('.btn-next')
    await expect(finishBtn).toContainText('Finish Tour')

    // Click Finish Tour
    await finishBtn.click()
    await expect(guideContainer).not.toBeVisible()

    // Verify localStorage completion
    const isCompleted = await page.evaluate(() => localStorage.getItem('sketch2solve_guide_completed'))
    expect(isCompleted).toBe('true')

    // Can be restarted from dashboard button
    const dashboardGuideBtn = page.locator('.dashboard-guide-btn')
    await expect(dashboardGuideBtn).toBeVisible()
    await dashboardGuideBtn.click()
    await expect(page.locator('.guide-container')).toBeVisible()
    await expect(page.locator('.step-title')).toContainText('1. Workspace & Dashboard')

    // Close with X button
    await page.locator('.guide-header .btn-icon[title="Close guide"]').click()
    await expect(page.locator('.guide-container')).not.toBeVisible()
  })

  test('3. Dark mode theme toggle, persistence, and visual contrast', async ({ page }) => {
    await page.goto('/')

    // Verify initial theme (or toggle to light first)
    const html = page.locator('html')
    const themeBtn = page.locator('.btn-theme-toggle')
    await expect(themeBtn).toBeVisible()

    const currentTheme = await html.getAttribute('data-theme')
    if (currentTheme !== 'dark') {
      await themeBtn.click()
    }
    await expect(html).toHaveAttribute('data-theme', 'dark')

    // Verify dark mode styling on dashboard
    const bodyBg = await page.evaluate(() => window.getComputedStyle(document.body).backgroundColor)
    expect(bodyBg).toMatch(/rgb\(15,\s*17,\s*21\)/)

    // Capture screenshot: Dashboard Dark Mode
    await page.screenshot({ path: path.resolve('qa-output/screenshots/05-dashboard-dark-mode.png') })

    // Reload: dark theme persists
    await page.reload()
    await expect(html).toHaveAttribute('data-theme', 'dark')

    // Toggle back to light
    await page.locator('.btn-theme-toggle').click()
    await expect(html).toHaveAttribute('data-theme', 'light')
    const lightBg = await page.evaluate(() => window.getComputedStyle(document.body).backgroundColor)
    expect(lightBg).toMatch(/rgb\(181,\s*185,\s*194\)/)
  })

  test('4. Truss Editor visual verification in Light and Dark themes', async ({ page }) => {
    // 1. Create a quick truss via Design Studio
    await page.goto('/?view=design')
    await expect(page.locator('.design-studio-page')).toBeVisible({ timeout: 10_000 })

    const textarea = page.locator('.studio-left-pane .design-textarea')
    await textarea.fill('Create a triangular truss with 6 m span and 3 m height')
    await page.locator('.studio-left-pane .btn-submit').click()
    await expect(page.locator('.studio-left-pane .design-proposal-card')).toBeVisible({ timeout: 15_000 })

    // 2. Apply and open editor
    await page.locator('.btn-apply-editor').click()
    await expect(page.locator('.truss-editor-workspace')).toBeVisible({ timeout: 10_000 })

    // 3. Capture editor in Light theme
    await page.evaluate(() => document.documentElement.setAttribute('data-theme', 'light'))
    await page.screenshot({ path: path.resolve('qa-output/screenshots/06-editor-light-mode.png') })

    // 4. Switch to Dark theme in Editor and verify canvas colors
    await page.evaluate(() => {
      document.documentElement.setAttribute('data-theme', 'dark')
      localStorage.setItem('sketch2solve_theme', 'dark')
    })
    await page.waitForTimeout(300)

    const canvasBg = await page.evaluate(() => {
      const el = document.querySelector('.canvas-container')
      return el ? window.getComputedStyle(el).backgroundColor : ''
    })
    expect(canvasBg).toMatch(/rgb\(19,\s*21,\s*24\)/)

    // Capture editor in Dark theme
    await page.screenshot({ path: path.resolve('qa-output/screenshots/07-editor-dark-mode.png') })
  })

  test('5. Analysis History page layout and Dark theme adaptation', async ({ page }) => {
    await page.goto('/?view=history')
    await expect(page.locator('.history-page')).toBeVisible({ timeout: 10_000 })

    // Set to dark theme
    await page.evaluate(() => {
      document.documentElement.setAttribute('data-theme', 'dark')
      localStorage.setItem('sketch2solve_theme', 'dark')
    })
    await page.waitForTimeout(300)

    // Verify footer and headers render cleanly
    await expect(page.locator('.history-header')).toBeVisible()

    // Capture History Dark Mode
    await page.screenshot({ path: path.resolve('qa-output/screenshots/08-history-dark-mode.png') })
  })

  test('6. Official Branding & Asset Verification', async ({ page }) => {
    await page.goto('/')

    // 1. Sidebar Brand logo image
    const brandLogo = page.locator('.sidebar .brand-logo-img')
    await expect(brandLogo).toBeVisible()
    expect(await brandLogo.getAttribute('src')).toBe('/logo.png')

    // 2. Direct static asset availability (200 OK)
    const logoResp = await page.request.get('/logo.png')
    expect(logoResp.status()).toBe(200)

    const faviconResp = await page.request.get('/favicon.png')
    expect(faviconResp.status()).toBe(200)

    const favicon32Resp = await page.request.get('/favicon-32x32.png')
    expect(favicon32Resp.status()).toBe(200)
  })
})

