import { test, expect } from '@playwright/test'

test.describe('Sketch2Solve Final Polish and Verification', () => {
  test('1. Natural Language Design geometry preview accurately renders geometry, supports, loads, and CAD grid', async ({ page }) => {
    await page.goto('/?view=design')
    await expect(page.locator('.design-studio-page')).toBeVisible({ timeout: 10_000 })

    const textarea = page.locator('.studio-left-pane .design-textarea')
    await textarea.fill('Create a triangular truss with a 6 m span and 3 m height with a pin at left, roller at right, and 10 kN downward load at top')
    await page.locator('.studio-left-pane .btn-submit').click()

    const proposalCard = page.locator('.studio-left-pane .design-proposal-card')
    await expect(proposalCard).toBeVisible({ timeout: 10_000 })

    // Inspect large geometry preview on the right
    const previewCanvas = page.locator('.studio-canvas-stage .cad-svg')
    await expect(previewCanvas).toBeVisible()

    // 1. Check straight structural lines exist
    const memberLines = previewCanvas.locator('.cad-member')
    await expect(memberLines).toHaveCount(3)

    // 2. Check joints and labels exist
    const joints = previewCanvas.locator('.cad-joint')
    await expect(joints).toHaveCount(3)

    // 3. Check pin and roller support symbols exist
    const pinSymbol = previewCanvas.locator('.cad-support.pin')
    const rollerSymbol = previewCanvas.locator('.cad-support.roller')
    await expect(pinSymbol).toBeVisible()
    await expect(rollerSymbol).toBeVisible()

    // 4. Check load vector arrow and magnitude label exist
    const loadArrow = previewCanvas.locator('.cad-load-arrow')
    const loadLabel = previewCanvas.locator('.cad-load-label')
    await expect(loadArrow).toBeVisible()
    await expect(loadLabel).toBeVisible()
    await expect(loadLabel).toContainText('10')

    // 5. Check CAD grid pattern exists
    const gridPattern = previewCanvas.locator('#cad-grid-pattern')
    await expect(gridPattern).toBeAttached()
  })

  test('2. Analysis History pagination footer adheres to design standards', async ({ page }) => {
    await page.goto('/?view=history')
    await expect(page.locator('.history-page')).toBeVisible({ timeout: 10_000 })

    // Check pagination footer exists with consistent design tokens
    const footer = page.locator('.history-pagination-footer')
    await expect(footer).toBeVisible()

    const paginationInfo = footer.locator('.pagination-info')
    await expect(paginationInfo).toBeVisible()
    await expect(paginationInfo).toContainText(/Showing \d+ of \d+ saved runs/)

    // Verify either Load More button is visible or All saved runs loaded is visible
    const hasLoadMore = await footer.locator('.btn-load-more').isVisible()
    const hasComplete = await footer.locator('.pagination-complete').isVisible()
    expect(hasLoadMore || hasComplete).toBe(true)
  })

  test('3. New Analysis evidence-card copy provides accurate, neutral explanation', async ({ page }) => {
    await page.goto('/?view=new')
    await expect(page.locator('.upload-card')).toBeVisible({ timeout: 10_000 })

    const step2 = page.locator('.workflow-step').nth(1)
    await expect(step2).toBeVisible()
    await expect(step2.locator('p')).toHaveText(
      'The selected AI provider interprets the sketch and proposes candidate joints, members, supports and loads for human review.'
    )
  })

  test('4. Issue Resolution Assistant is hidden by default and docks in bottom-right corner when opened', async ({ page }) => {
    // Navigate into the editor with a sample model
    await page.goto('/?view=design')
    const textarea = page.locator('.studio-left-pane .design-textarea')
    await textarea.fill('Create a triangular truss with 6 m span and 3 m height')
    await page.locator('.studio-left-pane .btn-submit').click()

    const proposalCard = page.locator('.studio-left-pane .design-proposal-card')
    await expect(proposalCard).toBeVisible({ timeout: 10_000 })
    await proposalCard.locator('.btn-apply').click()

    await expect(page.locator('.truss-editor-workspace')).toBeVisible({ timeout: 10_000 })

    // Verify IssueResolutionAssistant card is NOT visible initially
    const assistantCard = page.locator('.contextual-action-card')
    await expect(assistantCard).not.toBeVisible()

    // Toggle highlight using floating canvas control
    const alertBtn = page.locator('.canvas-floating-controls button[title*="Highlight detected issues"], .canvas-floating-controls button[aria-label*="Highlight detected issues"]')
    if (await alertBtn.isVisible()) {
      await alertBtn.click()
      // Now assistant card should be visible and docked at bottom-right
      await expect(assistantCard).toBeVisible()
      const box = await assistantCard.boundingBox()
      expect(box).toBeTruthy()

      // Verify close/clear button closes it
      const closeBtn = assistantCard.locator('.card-close-btn')
      await closeBtn.click()
      await expect(assistantCard).not.toBeVisible()
    }
  })

  test('5. Right sidebar tabbed workspace cleanly toggles between Tools and Design with AI', async ({ page }) => {
    await page.goto('/?view=design')
    const textarea = page.locator('.studio-left-pane .design-textarea')
    await textarea.fill('Create a triangular truss with 6 m span and 3 m height')
    await page.locator('.studio-left-pane .btn-submit').click()

    const proposalCard = page.locator('.studio-left-pane .design-proposal-card')
    await expect(proposalCard).toBeVisible({ timeout: 10_000 })
    await proposalCard.locator('.btn-apply').click()

    await expect(page.locator('.truss-editor-workspace')).toBeVisible({ timeout: 10_000 })

    // Verify tabs exist in sidebar
    const tabsNav = page.locator('.sidebar-tabs-nav')
    await expect(tabsNav).toBeVisible()

    const toolsTab = tabsNav.locator('.sidebar-tab-btn').filter({ hasText: 'Tools' })
    const designTab = tabsNav.locator('.sidebar-tab-btn').filter({ hasText: 'Design with AI' })
    await expect(toolsTab).toBeVisible()
    await expect(designTab).toBeVisible()

    // Initially Tools tab is active
    await expect(toolsTab).toHaveClass(/active/)
    await expect(page.locator('.sidebar-tools-pane')).toBeVisible()
    await expect(page.locator('.sidebar-design-pane')).not.toBeVisible()

    // Click Design with AI tab
    await designTab.click()
    await expect(designTab).toHaveClass(/active/)
    await expect(page.locator('.sidebar-design-pane')).toBeVisible()
    await expect(page.locator('.sidebar-tools-pane')).not.toBeVisible()

    // Topbar btn-ai switches back to Tools tab or toggles
    const topbarAiBtn = page.locator('.editor-topbar .btn-ai')
    await expect(topbarAiBtn).toHaveClass(/active/)
    await topbarAiBtn.click()
    await expect(toolsTab).toHaveClass(/active/)
    await expect(page.locator('.sidebar-tools-pane')).toBeVisible()
  })

  test('6. Construction and Structural tools use 3-column grid with uniform 48px tile height', async ({ page }) => {
    await page.goto('/?view=design')
    const textarea = page.locator('.studio-left-pane .design-textarea')
    await textarea.fill('Create a triangular truss with 6 m span and 3 m height')
    await page.locator('.studio-left-pane .btn-submit').click()

    const proposalCard = page.locator('.studio-left-pane .design-proposal-card')
    await expect(proposalCard).toBeVisible({ timeout: 10_000 })
    await proposalCard.locator('.btn-apply').click()

    await expect(page.locator('.truss-editor-workspace')).toBeVisible({ timeout: 10_000 })

    // Verify 3-column grid for Construction
    const constructionGrid = page.locator('.toolbox-group').filter({ hasText: 'Construction' }).locator('.tools-grid-3')
    await expect(constructionGrid).toBeVisible()
    await expect(constructionGrid.locator('.tool-tile')).toHaveCount(3)

    // Verify 3-column grid for Structural
    const structuralGrid = page.locator('.toolbox-group').filter({ hasText: 'Structural' }).locator('.tools-grid-3')
    await expect(structuralGrid).toBeVisible()
    await expect(structuralGrid.locator('.tool-tile')).toHaveCount(3)

    // Verify 1-column grid for Edit
    const editGrid = page.locator('.toolbox-group').filter({ hasText: 'Edit' }).locator('.tools-grid-1')
    await expect(editGrid).toBeVisible()
    await expect(editGrid.locator('.tool-tile')).toHaveCount(1)

    // Check height of tiles
    const tile = constructionGrid.locator('.tool-tile').first()
    const box = await tile.boundingBox()
    expect(box?.height).toBeGreaterThanOrEqual(47)
  })

  test('7. Sequential AI proposal generation, application, and model mutation', async ({ page }) => {
    await page.goto('/?view=design')
    const textarea = page.locator('.studio-left-pane .design-textarea')
    await textarea.fill('Create a triangular truss with a 6 m span and 3 m height with a pin at left, roller at right, and 10 kN downward load at top')
    await page.locator('.studio-left-pane .btn-submit').click()

    const proposalCard = page.locator('.studio-left-pane .design-proposal-card')
    await expect(proposalCard).toBeVisible({ timeout: 10_000 })
    await proposalCard.locator('.btn-apply').click()

    await expect(page.locator('.truss-editor-workspace')).toBeVisible({ timeout: 10_000 })

    // Switch to Design with AI tab in the editor
    await page.locator('.sidebar-tab-btn').filter({ hasText: 'Design with AI' }).click()
    const sidebarDesignPane = page.locator('.sidebar-design-pane')
    await expect(sidebarDesignPane).toBeVisible()

    // Formulate sequential modification
    const promptInput = sidebarDesignPane.locator('textarea')
    await promptInput.fill('Add a vertical strut from the apex to the bottom chord')
    await sidebarDesignPane.locator('.btn-submit').click()

    const modProposal = sidebarDesignPane.locator('.design-proposal-card')
    await expect(modProposal).toBeVisible({ timeout: 10_000 })

    // Apply the proposal
    await modProposal.locator('.btn-apply').click()

    // Verify toast notification and success
    await expect(page.locator('.editor-toast')).toBeVisible()
  })

  test('8. Model mutation and Undo support restores previous geometry state', async ({ page }) => {
    await page.goto('/?view=design')
    const textarea = page.locator('.studio-left-pane .design-textarea')
    await textarea.fill('Create a triangular truss with 6 m span and 3 m height')
    await page.locator('.studio-left-pane .btn-submit').click()

    const proposalCard = page.locator('.studio-left-pane .design-proposal-card')
    await expect(proposalCard).toBeVisible({ timeout: 10_000 })
    await proposalCard.locator('.btn-apply').click()

    await expect(page.locator('.truss-editor-workspace')).toBeVisible({ timeout: 10_000 })

    // Wait for nodes to be rendered
    await expect(page.locator('.truss-joint-node').first()).toBeVisible({ timeout: 10_000 })
    const initialJointCount = await page.locator('.truss-joint-node').count()
    expect(initialJointCount).toBeGreaterThanOrEqual(3)

    // Add a joint using the joint tool
    const jointTool = page.locator('.toolbox-group').filter({ hasText: 'Construction' }).locator('.tool-tile').filter({ hasText: 'Joint' })
    await jointTool.click()

    const canvas = page.locator('.engineering-svg')
    await canvas.click({ position: { x: 200, y: 200 } })

    const afterJointCount = await page.locator('.truss-joint-node').count()
    expect(afterJointCount).toBe(initialJointCount + 1)

    // Click Undo
    const undoBtn = page.locator('.editor-topbar button[aria-label="Undo"]')
    await undoBtn.click()

    const revertedJointCount = await page.locator('.truss-joint-node').count()
    expect(revertedJointCount).toBe(initialJointCount)
  })

  test('9. Revision conflict handling rejects stale proposals gracefully', async ({ page }) => {
    await page.goto('/?view=design')
    const textarea = page.locator('.studio-left-pane .design-textarea')
    await textarea.fill('Create a triangular truss with 6 m span and 3 m height')
    await page.locator('.studio-left-pane .btn-submit').click()

    const proposalCard = page.locator('.studio-left-pane .design-proposal-card')
    await expect(proposalCard).toBeVisible({ timeout: 10_000 })
    await proposalCard.locator('.btn-apply').click()

    await expect(page.locator('.truss-editor-workspace')).toBeVisible({ timeout: 10_000 })

    // Switch to Design with AI tab
    await page.locator('.sidebar-tab-btn').filter({ hasText: 'Design with AI' }).click()
    const sidebarDesignPane = page.locator('.sidebar-design-pane')

    const promptInput = sidebarDesignPane.locator('textarea')
    await promptInput.fill('Add a vertical strut')
    await sidebarDesignPane.locator('.btn-submit').click()

    const modProposal = sidebarDesignPane.locator('.design-proposal-card')
    await expect(modProposal).toBeVisible({ timeout: 10_000 })

    // Now modify the canvas geometry behind the proposal's back (switch to Tools and add a joint)
    await page.locator('.sidebar-tab-btn').filter({ hasText: 'Tools' }).click()
    const jointTool = page.locator('.toolbox-group').filter({ hasText: 'Construction' }).locator('.tool-tile').filter({ hasText: 'Joint' })
    await jointTool.click()
    await page.locator('.engineering-svg').click({ position: { x: 300, y: 150 } })

    // Switch back to Design with AI tab and attempt to apply the stale proposal
    await page.locator('.sidebar-tab-btn').filter({ hasText: 'Design with AI' }).click()
    await modProposal.locator('.btn-apply').click()

    // Verify conflict error message is displayed
    const errorNotice = sidebarDesignPane.locator('.error-banner')
    await expect(errorNotice).toBeVisible()
    await expect(errorNotice).toContainText(/Revision conflict|stale|modified/i)
  })
})
